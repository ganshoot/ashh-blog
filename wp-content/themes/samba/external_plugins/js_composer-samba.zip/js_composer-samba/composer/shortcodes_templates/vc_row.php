<?php
$output = $el_class = '';
extract(shortcode_atts(array(
    'el_class' => '',
    'bk_type' =>'',
    'bk_color' =>'',
    'bk_pattern' => '',
    'bk_image' => '',
    'align' => '',
    'text_color' => '',
    'parallax' => '',
    'bk_image' => '',
    'margin_type' => ''
), $atts));

//wp_enqueue_style( 'js_composer_front' );
//wp_enqueue_script( 'wpb_composer_front_js' );
//wp_enqueue_style('js_composer_custom_css');

$el_class = $this->getExtraClass($el_class);

$css_class =  apply_filters(VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, 'wpb_row '.get_row_css_class().$el_class, $this->settings['base']);

 //PIRENKO
//CLASSES
global $retina_device;
$prk_css_classes="";
if ($bk_type=="full_width")
    $prk_css_classes="prk_full_width prk_section";
else
    $prk_css_classes="prk_section centered columns";
if ($margin_type!="")
    $prk_css_classes.=" unmargined";
if (isset($parallax) && $parallax=="Yes")
    $prk_css_classes.=" parallaxed";
$prk_aria_frontend_options=get_option('aria_theme_options');
//OVERRIDE OPTIONS - ONLY FOR PREVIEW MODE
if (INJECT_STYLE)
{
include(ABSPATH . 'wp-content/plugins/color-manager-aria/style_header.php');  
}

//INLINE STYLES
$custom_style='style="';
if ($bk_color!="")
    $custom_style.="background-color:".$bk_color.";";
 if ($bk_pattern!="") {
    if ($retina_device=="prk_retina")
    {
        $path_parts = pathinfo(get_template_directory_uri()."/images/patterns/".$bk_pattern);
        $vt_image = vt_resize( '', get_template_directory_uri() . "/images/patterns/".$path_parts['filename']."_@2X.".$path_parts['extension'] , 2000, 2000, false );
        $half_width=$vt_image['width']/2;
        $custom_style .="background: url(" . get_template_directory_uri() . "/images/patterns/".$path_parts['filename']."_@2X.".$path_parts['extension']."); background-attachment: fixed;background-repeat:repeat;
        background-size:".$half_width."px auto;
        }";
    }
    else 
    {
        $custom_style.="background:url(".get_template_directory_uri() . "/images/patterns/".$bk_pattern.");background-attachment: fixed;background-repeat:repeat;";
    }
}
if ($bk_image!="") {
    $image_attributes = wp_get_attachment_image_src( $bk_image,'full' );
    $custom_style.="background-image:url(".$image_attributes[0].");";
    $prk_css_classes.=" prk_cover_back";
}
if ($text_color!="")
    $custom_style.="color:".$text_color.";";
if ($align!="")
    $custom_style.="text-align:".$align.";";
if ($custom_style!='style="')
    $custom_style.='"';
else
    $custom_style="";
if ($bk_type=="full_width") {
    $output .= '<div class="'.$css_class.' '.$prk_css_classes.'" '.$custom_style.'>';
        $output .= '<div class="prk_inner_block">';
            $output .= wpb_js_remove_wpautop($content);
        $output .= '</div>';
    $output .= '</div>'.$this->endBlockComment('row');
}
else {
    $output .= '<div class="row extra_size">';
        $output .= '<div class="prk_inner_block '.$css_class.' '.$prk_css_classes.'" '.$custom_style.'>';
            $output .= '<div class="centered">';
                $output .= wpb_js_remove_wpautop($content);
            $output .= '</div>';
        $output .= '</div>'.$this->endBlockComment('row');
    $output .= '</div>';
}
$output .='<div class="clearfix"></div>';
echo $output;